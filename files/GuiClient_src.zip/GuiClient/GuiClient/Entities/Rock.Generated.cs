#if ANDROID || IOS || DESKTOP_GL
#define REQUIRES_PRIMARY_THREAD_LOADING
#endif
using Color = Microsoft.Xna.Framework.Color;
using System.Linq;
using FlatRedBall.Graphics;
using FlatRedBall.Math;
using FlatRedBall;
using System;
using System.Collections.Generic;
using System.Text;
namespace GuiClient.Entities
{
    public partial class Rock : FlatRedBall.PositionedObject, FlatRedBall.Graphics.IDestroyable, FlatRedBall.Performance.IPoolable
    {
        // This is made static so that static lazy-loaded content can access it.
        public static string ContentManagerName { get; set; }
        #if DEBUG
        static bool HasBeenLoadedWithGlobalContentManager = false;
        #endif
        public class VariableState
        {
            public string Name;
            public static VariableState Size1 = new VariableState()
            {
                Name = "Size1",
            }
            ;
            public static VariableState Size2 = new VariableState()
            {
                Name = "Size2",
            }
            ;
            public static VariableState Size3 = new VariableState()
            {
                Name = "Size3",
            }
            ;
            public static VariableState Size4 = new VariableState()
            {
                Name = "Size4",
            }
            ;
            public static Dictionary<string, VariableState> AllStates = new Dictionary<string, VariableState>
            {
                {"Size1", Size1},
                {"Size2", Size2},
                {"Size3", Size3},
                {"Size4", Size4},
            }
            ;
        }
        private VariableState mCurrentState = null;
        public Entities.Rock.VariableState CurrentState
        {
            get
            {
                return mCurrentState;
            }
            set
            {
                mCurrentState = value;
                if (CurrentState == VariableState.Size1)
                {
                    SpriteTexture = Rock1;
                    CircleInstanceRadius = 3f;
                }
                else if (CurrentState == VariableState.Size2)
                {
                    SpriteTexture = Rock2;
                    CircleInstanceRadius = 6f;
                }
                else if (CurrentState == VariableState.Size3)
                {
                    SpriteTexture = Rock3;
                    CircleInstanceRadius = 20f;
                }
                else if (CurrentState == VariableState.Size4)
                {
                    SpriteTexture = Rock4;
                    CircleInstanceRadius = 30f;
                }
            }
        }
        static object mLockObject = new object();
        static System.Collections.Generic.List<string> mRegisteredUnloads = new System.Collections.Generic.List<string>();
        static System.Collections.Generic.List<string> LoadedContentManagers = new System.Collections.Generic.List<string>();
        protected static Microsoft.Xna.Framework.Graphics.Texture2D Rock1;
        protected static Microsoft.Xna.Framework.Graphics.Texture2D Rock2;
        protected static Microsoft.Xna.Framework.Graphics.Texture2D Rock3;
        protected static Microsoft.Xna.Framework.Graphics.Texture2D Rock4;
        
        private FlatRedBall.Sprite Sprite;
        private FlatRedBall.Math.Geometry.Circle mCircleInstance;
        public FlatRedBall.Math.Geometry.Circle CircleInstance
        {
            get
            {
                return mCircleInstance;
            }
            private set
            {
                mCircleInstance = value;
            }
        }
        public Microsoft.Xna.Framework.Graphics.Texture2D SpriteTexture
        {
            get
            {
                return Sprite.Texture;
            }
            set
            {
                Sprite.Texture = value;
            }
        }
        public float CircleInstanceRadius
        {
            get
            {
                return CircleInstance.Radius;
            }
            set
            {
                CircleInstance.Radius = value;
            }
        }
        public int NumberOfRocksToBreakInto = 2;
        public int RandomSpeedOnBreak = 50;
        public int PointsWorth = 10;
        public int Index { get; set; }
        public bool Used { get; set; }
        protected FlatRedBall.Graphics.Layer LayerProvidedByContainer = null;
        public Rock () 
        	: this(FlatRedBall.Screens.ScreenManager.CurrentScreen.ContentManagerName, true)
        {
        }
        public Rock (string contentManagerName) 
        	: this(contentManagerName, true)
        {
        }
        public Rock (string contentManagerName, bool addToManagers) 
        	: base()
        {
            ContentManagerName = contentManagerName;
            InitializeEntity(addToManagers);
        }
        protected virtual void InitializeEntity (bool addToManagers) 
        {
            LoadStaticContent(ContentManagerName);
            Sprite = new FlatRedBall.Sprite();
            Sprite.Name = "Sprite";
            mCircleInstance = new FlatRedBall.Math.Geometry.Circle();
            mCircleInstance.Name = "mCircleInstance";
            
            PostInitialize();
            if (addToManagers)
            {
                AddToManagers(null);
            }
        }
        public virtual void ReAddToManagers (FlatRedBall.Graphics.Layer layerToAddTo) 
        {
            LayerProvidedByContainer = layerToAddTo;
            FlatRedBall.SpriteManager.AddPositionedObject(this);
            FlatRedBall.SpriteManager.AddToLayer(Sprite, LayerProvidedByContainer);
            FlatRedBall.Math.Geometry.ShapeManager.AddToLayer(mCircleInstance, LayerProvidedByContainer);
        }
        public virtual void AddToManagers (FlatRedBall.Graphics.Layer layerToAddTo) 
        {
            LayerProvidedByContainer = layerToAddTo;
            FlatRedBall.SpriteManager.AddPositionedObject(this);
            FlatRedBall.SpriteManager.AddToLayer(Sprite, LayerProvidedByContainer);
            FlatRedBall.Math.Geometry.ShapeManager.AddToLayer(mCircleInstance, LayerProvidedByContainer);
            AddToManagersBottomUp(layerToAddTo);
            CustomInitialize();
        }
        public virtual void Activity () 
        {
            
            CustomActivity();
        }
        public virtual void Destroy () 
        {
            if (Used)
            {
                Factories.RockFactory.MakeUnused(this, false);
            }
            FlatRedBall.SpriteManager.RemovePositionedObject(this);
            
            if (Sprite != null)
            {
                FlatRedBall.SpriteManager.RemoveSpriteOneWay(Sprite);
            }
            if (CircleInstance != null)
            {
                FlatRedBall.Math.Geometry.ShapeManager.RemoveOneWay(CircleInstance);
            }
            CustomDestroy();
        }
        public virtual void PostInitialize () 
        {
            bool oldShapeManagerSuppressAdd = FlatRedBall.Math.Geometry.ShapeManager.SuppressAddingOnVisibilityTrue;
            FlatRedBall.Math.Geometry.ShapeManager.SuppressAddingOnVisibilityTrue = true;
            if (Sprite.Parent == null)
            {
                Sprite.CopyAbsoluteToRelative();
                Sprite.AttachTo(this, false);
            }
            Sprite.Texture = Rock1;
            Sprite.TextureScale = 1f;
            if (mCircleInstance.Parent == null)
            {
                mCircleInstance.CopyAbsoluteToRelative();
                mCircleInstance.AttachTo(this, false);
            }
            CircleInstance.Radius = 6f;
            FlatRedBall.Math.Geometry.ShapeManager.SuppressAddingOnVisibilityTrue = oldShapeManagerSuppressAdd;
        }
        public virtual void AddToManagersBottomUp (FlatRedBall.Graphics.Layer layerToAddTo) 
        {
            AssignCustomVariables(false);
        }
        public virtual void RemoveFromManagers () 
        {
            FlatRedBall.SpriteManager.ConvertToManuallyUpdated(this);
            if (Sprite != null)
            {
                FlatRedBall.SpriteManager.RemoveSpriteOneWay(Sprite);
            }
            if (CircleInstance != null)
            {
                FlatRedBall.Math.Geometry.ShapeManager.RemoveOneWay(CircleInstance);
            }
        }
        public virtual void AssignCustomVariables (bool callOnContainedElements) 
        {
            if (callOnContainedElements)
            {
            }
            Sprite.Texture = Rock1;
            Sprite.TextureScale = 1f;
            CircleInstance.Radius = 6f;
            CircleInstanceRadius = 6f;
            NumberOfRocksToBreakInto = 2;
            RandomSpeedOnBreak = 50;
            PointsWorth = 10;
        }
        public virtual void ConvertToManuallyUpdated () 
        {
            this.ForceUpdateDependenciesDeep();
            FlatRedBall.SpriteManager.ConvertToManuallyUpdated(this);
            FlatRedBall.SpriteManager.ConvertToManuallyUpdated(Sprite);
        }
        public static void LoadStaticContent (string contentManagerName) 
        {
            if (string.IsNullOrEmpty(contentManagerName))
            {
                throw new System.ArgumentException("contentManagerName cannot be empty or null");
            }
            ContentManagerName = contentManagerName;
            #if DEBUG
            if (contentManagerName == FlatRedBall.FlatRedBallServices.GlobalContentManager)
            {
                HasBeenLoadedWithGlobalContentManager = true;
            }
            else if (HasBeenLoadedWithGlobalContentManager)
            {
                throw new System.Exception("This type has been loaded with a Global content manager, then loaded with a non-global.  This can lead to a lot of bugs");
            }
            #endif
            bool registerUnload = false;
            if (LoadedContentManagers.Contains(contentManagerName) == false)
            {
                LoadedContentManagers.Add(contentManagerName);
                lock (mLockObject)
                {
                    if (!mRegisteredUnloads.Contains(ContentManagerName) && ContentManagerName != FlatRedBall.FlatRedBallServices.GlobalContentManager)
                    {
                        FlatRedBall.FlatRedBallServices.GetContentManagerByName(ContentManagerName).AddUnloadMethod("RockStaticUnload", UnloadStaticContent);
                        mRegisteredUnloads.Add(ContentManagerName);
                    }
                }
                if (!FlatRedBall.FlatRedBallServices.IsLoaded<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock1.png", ContentManagerName))
                {
                    registerUnload = true;
                }
                Rock1 = FlatRedBall.FlatRedBallServices.Load<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock1.png", ContentManagerName);
                if (!FlatRedBall.FlatRedBallServices.IsLoaded<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock2.png", ContentManagerName))
                {
                    registerUnload = true;
                }
                Rock2 = FlatRedBall.FlatRedBallServices.Load<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock2.png", ContentManagerName);
                if (!FlatRedBall.FlatRedBallServices.IsLoaded<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock3.png", ContentManagerName))
                {
                    registerUnload = true;
                }
                Rock3 = FlatRedBall.FlatRedBallServices.Load<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock3.png", ContentManagerName);
                if (!FlatRedBall.FlatRedBallServices.IsLoaded<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock4.png", ContentManagerName))
                {
                    registerUnload = true;
                }
                Rock4 = FlatRedBall.FlatRedBallServices.Load<Microsoft.Xna.Framework.Graphics.Texture2D>(@"content/entities/rock/rock4.png", ContentManagerName);
            }
            if (registerUnload && ContentManagerName != FlatRedBall.FlatRedBallServices.GlobalContentManager)
            {
                lock (mLockObject)
                {
                    if (!mRegisteredUnloads.Contains(ContentManagerName) && ContentManagerName != FlatRedBall.FlatRedBallServices.GlobalContentManager)
                    {
                        FlatRedBall.FlatRedBallServices.GetContentManagerByName(ContentManagerName).AddUnloadMethod("RockStaticUnload", UnloadStaticContent);
                        mRegisteredUnloads.Add(ContentManagerName);
                    }
                }
            }
            CustomLoadStaticContent(contentManagerName);
        }
        public static void UnloadStaticContent () 
        {
            if (LoadedContentManagers.Count != 0)
            {
                LoadedContentManagers.RemoveAt(0);
                mRegisteredUnloads.RemoveAt(0);
            }
            if (LoadedContentManagers.Count == 0)
            {
                if (Rock1 != null)
                {
                    Rock1= null;
                }
                if (Rock2 != null)
                {
                    Rock2= null;
                }
                if (Rock3 != null)
                {
                    Rock3= null;
                }
                if (Rock4 != null)
                {
                    Rock4= null;
                }
            }
        }
        static VariableState mLoadingState = null;
        public static VariableState LoadingState
        {
            get
            {
                return mLoadingState;
            }
            set
            {
                mLoadingState = value;
            }
        }
        public FlatRedBall.Instructions.Instruction InterpolateToState (VariableState stateToInterpolateTo, double secondsToTake) 
        {
            if (stateToInterpolateTo == VariableState.Size1)
            {
                CircleInstance.RadiusVelocity = (3f - CircleInstance.Radius) / (float)secondsToTake;
            }
            else if (stateToInterpolateTo == VariableState.Size2)
            {
                CircleInstance.RadiusVelocity = (6f - CircleInstance.Radius) / (float)secondsToTake;
            }
            else if (stateToInterpolateTo == VariableState.Size3)
            {
                CircleInstance.RadiusVelocity = (20f - CircleInstance.Radius) / (float)secondsToTake;
            }
            else if (stateToInterpolateTo == VariableState.Size4)
            {
                CircleInstance.RadiusVelocity = (30f - CircleInstance.Radius) / (float)secondsToTake;
            }
            var instruction = new FlatRedBall.Instructions.DelegateInstruction<VariableState>(StopStateInterpolation, stateToInterpolateTo);
            instruction.TimeToExecute = FlatRedBall.TimeManager.CurrentTime + secondsToTake;
            this.Instructions.Add(instruction);
            return instruction;
        }
        public void StopStateInterpolation (VariableState stateToStop) 
        {
            if (stateToStop == VariableState.Size1)
            {
                CircleInstance.RadiusVelocity =  0;
            }
            else if (stateToStop == VariableState.Size2)
            {
                CircleInstance.RadiusVelocity =  0;
            }
            else if (stateToStop == VariableState.Size3)
            {
                CircleInstance.RadiusVelocity =  0;
            }
            else if (stateToStop == VariableState.Size4)
            {
                CircleInstance.RadiusVelocity =  0;
            }
            CurrentState = stateToStop;
        }
        public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
        {
            #if DEBUG
            if (float.IsNaN(interpolationValue))
            {
                throw new System.Exception("interpolationValue cannot be NaN");
            }
            #endif
            bool setCircleInstanceRadius = true;
            float CircleInstanceRadiusFirstValue= 0;
            float CircleInstanceRadiusSecondValue= 0;
            if (firstState == VariableState.Size1)
            {
                if (interpolationValue < 1)
                {
                    this.SpriteTexture = Rock1;
                }
                CircleInstanceRadiusFirstValue = 3f;
            }
            else if (firstState == VariableState.Size2)
            {
                if (interpolationValue < 1)
                {
                    this.SpriteTexture = Rock2;
                }
                CircleInstanceRadiusFirstValue = 6f;
            }
            else if (firstState == VariableState.Size3)
            {
                if (interpolationValue < 1)
                {
                    this.SpriteTexture = Rock3;
                }
                CircleInstanceRadiusFirstValue = 20f;
            }
            else if (firstState == VariableState.Size4)
            {
                if (interpolationValue < 1)
                {
                    this.SpriteTexture = Rock4;
                }
                CircleInstanceRadiusFirstValue = 30f;
            }
            if (secondState == VariableState.Size1)
            {
                if (interpolationValue >= 1)
                {
                    this.SpriteTexture = Rock1;
                }
                CircleInstanceRadiusSecondValue = 3f;
            }
            else if (secondState == VariableState.Size2)
            {
                if (interpolationValue >= 1)
                {
                    this.SpriteTexture = Rock2;
                }
                CircleInstanceRadiusSecondValue = 6f;
            }
            else if (secondState == VariableState.Size3)
            {
                if (interpolationValue >= 1)
                {
                    this.SpriteTexture = Rock3;
                }
                CircleInstanceRadiusSecondValue = 20f;
            }
            else if (secondState == VariableState.Size4)
            {
                if (interpolationValue >= 1)
                {
                    this.SpriteTexture = Rock4;
                }
                CircleInstanceRadiusSecondValue = 30f;
            }
            if (setCircleInstanceRadius)
            {
                CircleInstanceRadius = CircleInstanceRadiusFirstValue * (1 - interpolationValue) + CircleInstanceRadiusSecondValue * interpolationValue;
            }
            if (interpolationValue < 1)
            {
                mCurrentState = firstState;
            }
            else
            {
                mCurrentState = secondState;
            }
        }
        public static void PreloadStateContent (VariableState state, string contentManagerName) 
        {
            ContentManagerName = contentManagerName;
            if (state == VariableState.Size1)
            {
                {
                    object throwaway = Rock1;
                }
            }
            else if (state == VariableState.Size2)
            {
                {
                    object throwaway = Rock2;
                }
            }
            else if (state == VariableState.Size3)
            {
                {
                    object throwaway = Rock3;
                }
            }
            else if (state == VariableState.Size4)
            {
                {
                    object throwaway = Rock4;
                }
            }
        }
        [System.Obsolete("Use GetFile instead")]
        public static object GetStaticMember (string memberName) 
        {
            switch(memberName)
            {
                case  "Rock1":
                    return Rock1;
                case  "Rock2":
                    return Rock2;
                case  "Rock3":
                    return Rock3;
                case  "Rock4":
                    return Rock4;
            }
            return null;
        }
        public static object GetFile (string memberName) 
        {
            switch(memberName)
            {
                case  "Rock1":
                    return Rock1;
                case  "Rock2":
                    return Rock2;
                case  "Rock3":
                    return Rock3;
                case  "Rock4":
                    return Rock4;
            }
            return null;
        }
        object GetMember (string memberName) 
        {
            switch(memberName)
            {
                case  "Rock1":
                    return Rock1;
                case  "Rock2":
                    return Rock2;
                case  "Rock3":
                    return Rock3;
                case  "Rock4":
                    return Rock4;
            }
            return null;
        }
        protected bool mIsPaused;
        public override void Pause (FlatRedBall.Instructions.InstructionList instructions) 
        {
            base.Pause(instructions);
            mIsPaused = true;
        }
        public virtual void SetToIgnorePausing () 
        {
            FlatRedBall.Instructions.InstructionManager.IgnorePausingFor(this);
            FlatRedBall.Instructions.InstructionManager.IgnorePausingFor(Sprite);
            FlatRedBall.Instructions.InstructionManager.IgnorePausingFor(CircleInstance);
        }
        public virtual void MoveToLayer (FlatRedBall.Graphics.Layer layerToMoveTo) 
        {
            var layerToRemoveFrom = LayerProvidedByContainer;
            if (layerToRemoveFrom != null)
            {
                layerToRemoveFrom.Remove(Sprite);
            }
            if (layerToMoveTo != null || !SpriteManager.AutomaticallyUpdatedSprites.Contains(Sprite))
            {
                FlatRedBall.SpriteManager.AddToLayer(Sprite, layerToMoveTo);
            }
            if (layerToRemoveFrom != null)
            {
                layerToRemoveFrom.Remove(CircleInstance);
            }
            FlatRedBall.Math.Geometry.ShapeManager.AddToLayer(CircleInstance, layerToMoveTo);
            LayerProvidedByContainer = layerToMoveTo;
        }
    }
}
