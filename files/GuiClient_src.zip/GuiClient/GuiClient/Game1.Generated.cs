namespace GuiClient
{
    public partial class Game1
    {
        partial void GeneratedInitialize () 
        {
        }
        partial void GeneratedUpdate (Microsoft.Xna.Framework.GameTime gameTime) 
        {
        }
        partial void GeneratedDraw (Microsoft.Xna.Framework.GameTime gameTime) 
        {
        }
    }
}
