using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuiClient.Performance
{
    public interface IEntityFactory
    {
        object CreateNew(float x = 0, float y = 0);
        object CreateNew(FlatRedBall.Graphics.Layer layer);

        void Initialize(string contentManager);
        void ClearListsToAddTo();
    }
}
