namespace GuiClient
{
    public class FileAliasLogic
    {
        public static void SetFileAliases () 
        {
        }
    }
}
