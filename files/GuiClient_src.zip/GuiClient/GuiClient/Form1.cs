﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameLib;



namespace GuiClient
{
    public partial class Form1 : Form
    {
        GameClient client = new GameClient("127.0.0.1", 8800);
        GameInfo info;
        const int bm_size = 600; 
        Bitmap bm = new Bitmap(bm_size, bm_size);

        public Form1()
        {
            InitializeComponent();

            pictureBox1.Image = bm;

            pictureBox1.Invalidate();
            client.OnGameInfoReceived += Client_OnGameInfoReceived;
            client.OnGameStateReceived += Client_OnGameStateReceived;
            client.ConnectAsync();

        }

        private PlayerAction Client_OnGameStateReceived(GameState state)
        {
            Vector2D force = new Vector2D(mouse_loc.X - bm_size / 2.0f, mouse_loc.Y - bm_size / 2.0f);

            try
            {
                this.Invoke((MethodInvoker)delegate
                {
                    Draw(state, force);

                });
            }
            catch { }


            return new PlayerAction(info.Key, force);
        }

        private void Client_OnGameInfoReceived(GameInfo info)
        {
            this.info = info;
        }

        public void Draw(GameState state, Vector2D force)
        {
            Player myself = state.Players.Find(o => { return o.id == info.MyId; });
            if (myself == null)
                return;
            Vector2D center = myself.pos;

            label1.Text = state.Tick.ToString();
            label2.Text = force.x.ToString("F1") + " " + force.y.ToString("F1");

            using (var g = Graphics.FromImage(bm))
            {
                g.Clear(Color.Black);

                DrawMyself(g, center, myself);

                foreach (var p in state.Players)
                    DrawPlayer(g, center, p);

                foreach (var p in state.Dust)
                    DrawDust(g, center, p);
            }

            pictureBox1.Invalidate();
        }

        public void DrawDust(Graphics g, Vector2D center, Circle p)
        {
            using (Pen pen = new Pen(Color.Cyan))
            {
                float x = p.pos.x - p.r - center.x + bm_size / 2.0f;
                float y = p.pos.y - p.r - center.y + bm_size / 2.0f;
                g.DrawEllipse(pen, x, y, p.r * 2.0f, p.r * 2.0f);
            }
        }

        public void DrawMyself(Graphics g, Vector2D center, Player p)
        {
            using (Pen pen = new Pen(Color.Yellow))
            {
                float x = p.pos.x - center.x + bm_size / 2.0f;
                float y = p.pos.y - center.y + bm_size / 2.0f;
                g.DrawEllipse(pen, x - p.r, y - p.r, p.r * 2.0f, p.r * 2.0f) ;
                g.DrawLine(pen, x, y, x + p.vel.x, y + p.vel.y);
            }
        }
        public void DrawPlayer(Graphics g, Vector2D center, Player p)
        {
            using (Pen pen = new Pen(Color.Red))
            {
                float x = p.pos.x - p.r - center.x + bm_size / 2.0f;
                float y = p.pos.y - p.r - center.y + bm_size / 2.0f;
                g.DrawEllipse(pen, x, y, p.r * 2.0f, p.r * 2.0f);
            }
        }

        Point mouse_loc = new Point(0, 0);
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            mouse_loc = e.Location;
        }
    }
}
