#if ANDROID || IOS || DESKTOP_GL
#define REQUIRES_PRIMARY_THREAD_LOADING
#endif
using Color = Microsoft.Xna.Framework.Color;
using System.Linq;
using FlatRedBall;
using System;
using System.Collections.Generic;
using System.Text;
namespace GuiClient.Screens
{
    public partial class GameScreen : FlatRedBall.Screens.Screen
    {
        #if DEBUG
        static bool HasBeenLoadedWithGlobalContentManager = false;
        #endif
        
        private FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.Bullet> BulletList;
        private FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.MainShip> MainShipList;
        private GuiClient.Entities.MainShip MainShip1;
        private FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.Explosion> ExplosionList;
        private GuiClient.Entities.Hud HudInstance;
        private GuiClient.Entities.EndGameUi EndGameUiInstance;
        private FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.Dust> DustList;
        public GameScreen () 
        	: base ("GameScreen")
        {
        }
        public override void Initialize (bool addToManagers) 
        {
            LoadStaticContent(ContentManagerName);
            BulletList = new FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.Bullet>();
            BulletList.Name = "BulletList";
            MainShipList = new FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.MainShip>();
            MainShipList.Name = "MainShipList";
            MainShip1 = new GuiClient.Entities.MainShip(ContentManagerName, false);
            MainShip1.Name = "MainShip1";
            ExplosionList = new FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.Explosion>();
            ExplosionList.Name = "ExplosionList";
            HudInstance = new GuiClient.Entities.Hud(ContentManagerName, false);
            HudInstance.Name = "HudInstance";
            EndGameUiInstance = new GuiClient.Entities.EndGameUi(ContentManagerName, false);
            EndGameUiInstance.Name = "EndGameUiInstance";
            DustList = new FlatRedBall.Math.PositionedObjectList<GuiClient.Entities.Dust>();
            DustList.Name = "DustList";
            
            
            PostInitialize();
            base.Initialize(addToManagers);
            if (addToManagers)
            {
                AddToManagers();
            }
        }
        public override void AddToManagers () 
        {
            Factories.BulletFactory.Initialize(ContentManagerName);
            Factories.DustFactory.Initialize(ContentManagerName);
            Factories.BulletFactory.AddList(BulletList);
            Factories.DustFactory.AddList(DustList);
            MainShip1.AddToManagers(mLayer);
            HudInstance.AddToManagers(mLayer);
            EndGameUiInstance.AddToManagers(mLayer);
            base.AddToManagers();
            AddToManagersBottomUp();
            CustomInitialize();
        }
        public override void Activity (bool firstTimeCalled) 
        {
            if (!IsPaused)
            {
                
                HudInstance.Activity();
                EndGameUiInstance.Activity();
            }
            else
            {
            }
            base.Activity(firstTimeCalled);
            if (!IsActivityFinished)
            {
                CustomActivity(firstTimeCalled);
            }
        }
        public override void Destroy () 
        {
            base.Destroy();
            Factories.BulletFactory.Destroy();
            Factories.DustFactory.Destroy();
            
            BulletList.MakeOneWay();
            MainShipList.MakeOneWay();
            ExplosionList.MakeOneWay();
            DustList.MakeOneWay();
            for (int i = BulletList.Count - 1; i > -1; i--)
            {
                BulletList[i].Destroy();
            }
            for (int i = MainShipList.Count - 1; i > -1; i--)
            {
                MainShipList[i].Destroy();
            }
            for (int i = ExplosionList.Count - 1; i > -1; i--)
            {
                ExplosionList[i].Destroy();
            }
            if (HudInstance != null)
            {
                HudInstance.Destroy();
                HudInstance.Detach();
            }
            if (EndGameUiInstance != null)
            {
                EndGameUiInstance.Destroy();
                EndGameUiInstance.Detach();
            }
            for (int i = DustList.Count - 1; i > -1; i--)
            {
                DustList[i].Destroy();
            }
            BulletList.MakeTwoWay();
            MainShipList.MakeTwoWay();
            ExplosionList.MakeTwoWay();
            DustList.MakeTwoWay();
            FlatRedBall.Math.Collision.CollisionManager.Self.Relationships.Clear();
            CustomDestroy();
        }
        public virtual void PostInitialize () 
        {
            bool oldShapeManagerSuppressAdd = FlatRedBall.Math.Geometry.ShapeManager.SuppressAddingOnVisibilityTrue;
            FlatRedBall.Math.Geometry.ShapeManager.SuppressAddingOnVisibilityTrue = true;
            MainShipList.Add(MainShip1);
            FlatRedBall.Math.Geometry.ShapeManager.SuppressAddingOnVisibilityTrue = oldShapeManagerSuppressAdd;
        }
        public virtual void AddToManagersBottomUp () 
        {
            CameraSetup.ResetCamera(SpriteManager.Camera);
            AssignCustomVariables(false);
        }
        public virtual void RemoveFromManagers () 
        {
            for (int i = BulletList.Count - 1; i > -1; i--)
            {
                BulletList[i].Destroy();
            }
            for (int i = MainShipList.Count - 1; i > -1; i--)
            {
                MainShipList[i].Destroy();
            }
            for (int i = ExplosionList.Count - 1; i > -1; i--)
            {
                ExplosionList[i].Destroy();
            }
            HudInstance.RemoveFromManagers();
            EndGameUiInstance.RemoveFromManagers();
            for (int i = DustList.Count - 1; i > -1; i--)
            {
                DustList[i].Destroy();
            }
        }
        public virtual void AssignCustomVariables (bool callOnContainedElements) 
        {
            if (callOnContainedElements)
            {
                MainShip1.AssignCustomVariables(true);
                HudInstance.AssignCustomVariables(true);
                EndGameUiInstance.AssignCustomVariables(true);
            }
        }
        public virtual void ConvertToManuallyUpdated () 
        {
            for (int i = 0; i < BulletList.Count; i++)
            {
                BulletList[i].ConvertToManuallyUpdated();
            }
            for (int i = 0; i < MainShipList.Count; i++)
            {
                MainShipList[i].ConvertToManuallyUpdated();
            }
            for (int i = 0; i < ExplosionList.Count; i++)
            {
                ExplosionList[i].ConvertToManuallyUpdated();
            }
            HudInstance.ConvertToManuallyUpdated();
            EndGameUiInstance.ConvertToManuallyUpdated();
            for (int i = 0; i < DustList.Count; i++)
            {
                DustList[i].ConvertToManuallyUpdated();
            }
        }
        public static void LoadStaticContent (string contentManagerName) 
        {
            if (string.IsNullOrEmpty(contentManagerName))
            {
                throw new System.ArgumentException("contentManagerName cannot be empty or null");
            }
            #if DEBUG
            if (contentManagerName == FlatRedBall.FlatRedBallServices.GlobalContentManager)
            {
                HasBeenLoadedWithGlobalContentManager = true;
            }
            else if (HasBeenLoadedWithGlobalContentManager)
            {
                throw new System.Exception("This type has been loaded with a Global content manager, then loaded with a non-global.  This can lead to a lot of bugs");
            }
            #endif
            GuiClient.Entities.Hud.LoadStaticContent(contentManagerName);
            GuiClient.Entities.EndGameUi.LoadStaticContent(contentManagerName);
            CustomLoadStaticContent(contentManagerName);
        }
        public override void PauseThisScreen () 
        {
            StateInterpolationPlugin.TweenerManager.Self.Pause();
            base.PauseThisScreen();
        }
        public override void UnpauseThisScreen () 
        {
            StateInterpolationPlugin.TweenerManager.Self.Unpause();
            base.UnpauseThisScreen();
        }
        [System.Obsolete("Use GetFile instead")]
        public static object GetStaticMember (string memberName) 
        {
            return null;
        }
        public static object GetFile (string memberName) 
        {
            return null;
        }
        object GetMember (string memberName) 
        {
            return null;
        }
    }
}
