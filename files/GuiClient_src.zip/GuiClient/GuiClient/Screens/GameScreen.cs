using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using FlatRedBall;
using FlatRedBall.Input;
using FlatRedBall.Instructions;
using FlatRedBall.AI.Pathfinding;
using FlatRedBall.Graphics.Animation;
using FlatRedBall.Graphics.Particle;
using FlatRedBall.Math.Geometry;
using FlatRedBall.Localization;
using GameClient2;
using GameLib;
using Microsoft.Xna.Framework;

namespace GuiClient.Screens
{
    public partial class GameScreen
    {
        GameClient cl;
        GameState currentstate;
        InputController input_controller;
        void CustomInitialize()
        {
            FlatRedBallServices.Game.IsMouseVisible = true;
            FlatRedBallServices.Game.Window.AllowUserResizing = true;
            input_controller = InputController.CreateInputController();
            //cl = new GameClient("ws://127.0.0.1:8800");
            cl = new GameClient("ws://62.173.140.96:80");
            cl.OnGameInfoReceived += this.Cl_OnGameInfoReceived;
            cl.OnGameStateReceived += this.Cl_OnGameStateReceived;
            cl.Connect();
        }

        private PlayerAction Cl_OnGameStateReceived(GameState state)
        {
            currentstate = state;
            PlayerAction action = input_controller.GetAction(state);
            action.Shoot = true;
            return action;
        }
        GameInfo myinfo = new GameInfo();
        private void Cl_OnGameInfoReceived(GameInfo info)
        {
            myinfo = info;
            input_controller.SetInfo(info);
        }

        private void ManageBullets()
        {
            foreach (var s in BulletList)
                s.Destroy();
            if (currentstate != null)
            {
                foreach (var p in currentstate.Bullets)
                {
                    Entities.Bullet bullet = new Entities.Bullet(ContentManagerName);
                    bullet.Position.X = p.pos.x;
                    bullet.Position.Y = p.pos.y;
                    float? angle = new Vector2(p.vel.y, -p.vel.x).Angle();
                    bullet.RotationZ = (angle == null) ? 0.0f : (float)angle;
                    BulletList.Add(bullet);
                }
            }
        }
        private void ManageDust()
        {
            foreach (var s in DustList)
                s.Destroy();
            if (currentstate != null)
            {
                foreach (var p in currentstate.Dust)
                {
                    Entities.Dust dust = new Entities.Dust(ContentManagerName);
                    dust.Position.X = p.pos.x;
                    dust.Position.Y = p.pos.y;
                    DustList.Add(dust);
                }
            }
        }
        private void ManagePlayers()
        {
            foreach (var s in MainShipList)
                s.Destroy();

            if (currentstate != null)
            {
                foreach (var p in currentstate.Players)
                {
                    Entities.MainShip mainShip = new Entities.MainShip(ContentManagerName);
                    mainShip.id = p.id;
                    MainShipList.Add(mainShip);
                    mainShip.Position.X = p.pos.x;
                    mainShip.Position.Y = p.pos.y;
                    float? angle = new Vector2(p.vel.y, -p.vel.x).Angle();
                    mainShip.RotationZ = (angle == null) ? 0.0f : (float)angle;
                }
            }
        }

        void CustomActivity(bool firstTimeCalled)
        {
            ManagePlayers();
            ManageDust();
            ManageBullets();
        }

        void CustomDestroy()
        {


        }

        private static void CustomLoadStaticContent(string contentManagerName)
        {


        }

    }

}
