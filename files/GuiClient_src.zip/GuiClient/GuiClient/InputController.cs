﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using FlatRedBall.Input;
using GameLib;
using OpenTK.Graphics.OpenGL;
using System.Diagnostics;

namespace GuiClient
{
    public abstract class InputController
    {
        public static InputController CreateInputController()
        {
            if (Console.IsInputRedirected)
                return new ConsoleInputController();
            else
                return new MouseInputController();
        }
        public string key;

        public abstract PlayerAction GetAction(GameState state);
        public abstract void SetInfo(GameInfo info);
    }

    public class MouseInputController : InputController
    {
        public override PlayerAction GetAction(GameState state)
        {
            Vector2D c = new Vector2D();
            c.x = FlatRedBall.Gui.GuiManager.Cursor.WorldXAt(0);
            c.y = FlatRedBall.Gui.GuiManager.Cursor.WorldYAt(0);
            PlayerAction ret = new PlayerAction(key, c);
            return ret;
        }
        public override void SetInfo(GameInfo info)
        {
            this.key = info.Key;
        }
    }

    public class ConsoleInputController : InputController
    {

        public override PlayerAction GetAction(GameState state)
        {
            Console.WriteLine(JsonSerDes.Serialize(state));
            string s = Console.ReadLine();
            PlayerAction a = JsonSerDes.DeserializeAction(s);
            return a;
        }
        public override void SetInfo(GameInfo info)
        {
            this.key = info.Key;
            string s = JsonSerDes.Serialize(info);
            Console.WriteLine(s);
        }
    }
}
