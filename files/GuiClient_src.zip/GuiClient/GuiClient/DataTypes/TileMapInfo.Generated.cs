
namespace GuiClient.DataTypes
{
    public partial class TileMapInfo
    {
        public string Name;
        public System.Collections.Generic.List<FlatRedBall.Content.AnimationChain.AnimationFrameSave> EmbeddedAnimation;
        
        
    }
}
